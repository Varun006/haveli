<nav id="primary-menu">

    <ul>
        <li class="">
            <a href="/">
                <div>Home</div>
            </a>
        </li>

        <li class="">
            <a href="events">
                <div>Events</div>
            </a>
        </li>


        <li class="">
            <a href="photos">
                <div>Gallery</div>
            </a>
        </li>

        <li class="">
            <a href="about">
                <div>About Haveli</div>
            </a>
        </li>

        <li class="">
            <a href="darshan">
                <div>Darshan Timings</div>
            </a>
        </li>

        <li class="">
            <a href="/contact">
                <div>Contact Us</div>
            </a>
        </li>
        
	</ul>
 
</nav>	


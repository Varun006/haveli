@extends('public.layouts.main')

@section('extra-css')
@stop

@section('content')
<div id="page-menu">

	<div id="page-menu-wrap">

		<div class="container clearfix">

			<div class="menu-title center">About <span>Govardhan Haveli</span></div>

		</div>

	</div>

</div><!-- #page-menu end -->

<section id="content">
	<div class="content-wrap">
		<div class="container clearfix">
			<div class="col_full">
				<div class="heading-block center">
					<h2>About Haveli</h2>
				</div>

				<p class="topmargin" style="font-size: 1.6rem;">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis deleniti laboriosam dolorum, reiciendis necessitatibus nihil distinctio nulla sint minus, beatae hic consectetur. Voluptates error laudantium, culpa dolorum, laborum delectus tempora! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Necessitatibus quia incidunt tempora sunt debitis ut ab quos sapiente maxime, accusantium ullam eligendi maiores et deleniti excepturi obcaecati neque, consequuntur quidem. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus dolorem illum sunt deserunt iste repellat, id veniam. Voluptas officiis, ea, sit facilis numquam recusandae ipsum aspernatur nobis saepe eos architecto. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus odio nihil animi totam vel hic vitae, aliquid veritatis ex ullam, asperiores consectetur ipsam aspernatur et explicabo saepe iste debitis ea. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci laborum architecto amet rem vel, fuga, praesentium inventore magnam voluptate et delectus. Animi saepe autem ea, id asperiores quidem rerum at!</p>
			</div>
		</div>
	</div>
</section>			
@stop

@section('extra-js')
@stop
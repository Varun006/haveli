<?php $__env->startSection('extra-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-menu">

	<div id="page-menu-wrap">

		<div class="container clearfix">

			<div class="menu-title center"> <span>Photos</span></div>

		</div>

	</div>

</div><!-- #page-menu end -->

<section id="content">
	<div class="content-wrap">
		<div class="container clearfix">
			<div class="col_full">
				<div class="fancy-title title-border">
					<h3>Gallery</h3>
				</div>
				<div class="nobottommargin clearfix" data-lightbox="gallery">
					<div class="col-xs-6 col-md-3 topmargin">
						<a href="gallery/g1.jpg" data-lightbox="gallery-item"><img class="image_fade" src="gallery/g1.jpg" alt="Gallery Thumb 1"></a>
					</div>

					<div class="col-xs-6 col-md-3 topmargin">
						<a href="gallery/g2.jpg" data-lightbox="gallery-item"><img class="image_fade" src="gallery/g2.jpg" alt="Gallery Thumb 1"></a>
					</div>

					<div class="col-xs-6 col-md-3 topmargin">
						<a href="gallery/g3.jpg" data-lightbox="gallery-item"><img class="image_fade" src="gallery/g3.jpg" alt="Gallery Thumb 1"></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<?php $__env->stopSection(); ?>		
<?php echo $__env->make('public.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
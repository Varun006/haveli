<!DOCTYPE html>
<html dir="ltr" lang="en-US">

	<head>

		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="author" content="VashiHaveli" />

		<!-- Stylesheets
		============================================= -->
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/bootstrap.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/style.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/swiper.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/dark.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/font-icons.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/animate.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/magnific-popup.css')); ?>" type="text/css" />
		<link rel="stylesheet" href="<?php echo e(@asset('css/colors.css')); ?>" type="text/css" />
		
		<?php echo $__env->yieldContent('extra-css'); ?>

		<link rel="stylesheet" href="<?php echo e(@asset('css/responsive.css')); ?>" type="text/css" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />

		<link rel="icon" href="<?php echo e(@asset('images/logo.png')); ?>" type="image/png" sizes="16x16">
		
		<link rel="apple-touch-icon" href="<?php echo e(@asset('images/logo.png')); ?>">

    	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(@asset('images/logo.png')); ?>">

    	<link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(@asset('images/logo.png')); ?>">

	    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(@asset('images/logo.png')); ?>">

		<meta name="viewport" content="width=device-width, initial-scale=1" />

        <meta name="_token" content="<?php echo e(csrf_token()); ?>"/>
		<!--[if lt IE 9]>
			<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<![endif]-->

		<!-- Document Title
		============================================= -->
		<title>Haveli</title>

		<style>

            footer{

                margin-top: 0px !important;

            }

        </style>

	</head>

<body class="stretched">
	
	<div id="wrapper" class="clearfix">

			<!-- Header
			============================================= -->
			<header id="header" class="full-header transparant">

				<div id="header-wrap">

					<div class="container clearfix">

						<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

						<!-- Logo

							============================================= -->

							<div id="logo">

								<a href="/" class="standard-logo" data-dark-logo=<?php echo e(@asset('logo.png')); ?>><img src=<?php echo e(@asset('logo.png')); ?> alt="Logo"></a>

								<a href="/" class="retina-logo" data-dark-logo=<?php echo e(@asset('logo.png')); ?>><img src=<?php echo e(@asset('logo.png')); ?> alt="Logo"></a>

							</div><!-- #logo end -->

							<!-- Logo 
							============================================= -->

							<?php echo $__env->make('public.layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						
					</div>
				
				</div>
				
			</header>		

			<?php echo $__env->yieldContent('slider'); ?>
			
			<?php echo $__env->yieldContent('content'); ?>
			
			<?php echo $__env->make('public.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>		

<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>
	
	 <?php echo $__env->yieldContent('extra-js'); ?>

	<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?php echo e(@asset('js/plugins.js')); ?>"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?php echo e(@asset('js/functions.js')); ?>"></script>

	</body>

</html>
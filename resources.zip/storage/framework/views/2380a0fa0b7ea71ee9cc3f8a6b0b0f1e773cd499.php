<?php $__env->startSection('extra-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Sub Menu
		============================================= -->
<div id="page-menu">

	<div id="page-menu-wrap">

		<div class="container clearfix">

			<div class="menu-title center">Darshan <span>Timings</span></div>

		</div>

	</div>

</div><!-- #page-menu end -->
<section id="content">
	<div class="content-wrap">
		<div class="container clearfix">
			<div class="table-responsive">
			  <table class="table table-bordered nobottommargin">
				<thead>
				  <tr>
					<th>#</th>
					<th>Table heading</th>
					<th>Table heading</th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td>1</td>
					<td>Table cell</td>
					<td>Table cell</td>
				  </tr>
				  <tr>
					<td>2</td>
					<td>Table cell</td>
					<td>Table cell</td>
				  </tr>
				  <tr>
					<td>3</td>
					<td>Table cell</td>
					<td>Table cell</td>
				  </tr>
				</tbody>
			  </table>
			</div>
		</div>
	</div>
</section>		
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>